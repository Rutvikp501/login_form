var mongoose = require('mongoose');
var Schema = mongoose.Schema;

const ImgSchema = new Schema( {
	//document_type:{ type: String, trim: true },
	Profile_img:{type:String, required: false , trim:true }
	
},{timestamps:true})
const Img = mongoose.model('Img', ImgSchema);

export default Img 